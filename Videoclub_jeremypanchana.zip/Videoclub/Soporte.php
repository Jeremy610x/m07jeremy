<?php


class Soporte{

public string $titulo;
public int $numero;
public float $precio;

private static float $iva = 21.0;

public function __construct (string $titulo , int $numero,float $precio){
    $this->titulo = $titulo;
    $this ->numero = $numero;
    $this->precio = $precio;
}

public function getPrecio(): float {
    return $this->precio;
}
public function getNumero(): int {
    return $this->numero;
}
public function getPrecioConIVA():float{

return $this ->precio * (1+self::$iva /100);

}

public function muestraResumen(): void {
    echo "<br><strong>Resumen del Soporte</strong>:<br>";
    echo "Titulo: {$this->titulo}<br>";
    echo "Numero: {$this->getNumero()}<br>";
    echo "Precio: {$this->getPrecio()} euros<br>";
    echo "Precio con IVA: {$this->getPrecioConIVA()} euros<br>";
}



}