<?php
include "Soporte.php";


class Dvd extends Soporte{

    private string $idiomas;
private string $formatpantalla;


public function __construct(string $titulo, int $numero, float $precio, string $idiomas, string $formatpantalla) {
    
    parent::__construct($titulo, $numero, $precio);
    $this->idiomas = $idiomas;
    $this->formatpantalla = $formatpantalla;
}

public function muestraResumen(): void {
    
    parent::muestraResumen();
    echo "Idiomas: {$this->idiomas}<br>";
    echo "Formato de pantalla: {$this->formatpantalla}<br>";
}


}

?>