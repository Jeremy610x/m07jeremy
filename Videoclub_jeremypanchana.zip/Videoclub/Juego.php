<?php

include "Soporte.php";


class Juego extends Soporte {

    private string $consola; 
    private int $minNumJugadores; 
    private int $maxNumJugadores; 


public function __construct(string $titulo, int $numero, float $precio, string $consola, int $minNumJugadores, int $maxNumJugadores) {

    parent::__construct($titulo, $numero, $precio);
    $this->consola = $consola;
    $this->minNumJugadores = $minNumJugadores;
    $this->maxNumJugadores = $maxNumJugadores;
}

    public function muestraJugadoresPosibles(): string {
        if ($this->minNumJugadores === $this->maxNumJugadores) {
            if ($this->minNumJugadores === 1) {
                return "Para un jugador";
            } else {
                return "Para {$this->minNumJugadores} jugadores";
            }
        } else {
            return "De {$this->minNumJugadores} a {$this->maxNumJugadores} jugadores";
        }
    }


    public function muestraResumen(): void {
        parent::muestraResumen();
        echo "Consola: {$this->consola}<br>";
        echo "Jugadores: " . $this->muestraJugadoresPosibles() . "<br>";
    }



}